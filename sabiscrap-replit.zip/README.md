# SabiScrap — MVP UI Mockup

Mobile-first UI mockup for a Bayelsa/Rivers-focused waste marketplace. Five core screens: role select, marketplace/home, list waste, AI estimate + collector match, wallet.

## Files
- `index.html` — page structure
- `style.css` — design tokens (colors, type, layout) and all screen styling
- `script.js` — tab switching between screens

## Run on Replit
1. Create a new Repl → **Import from GitHub** (if pushed to a repo) or **Upload folder** and drop these files in.
2. Choose the **HTML/CSS/JS** template if prompted, or just keep the included `.replit` config — it serves the folder with Python's built-in static server on port 3000.
3. Click **Run**. The webview will open showing the mockup with the tab bar at the top to jump between screens.

## Run locally
No build step needed — it's plain HTML/CSS/JS.
```
python3 -m http.server 3000
```
Then open `http://localhost:3000`.

## Next steps for a real MVP
This is a clickable visual mockup, not a functional app — buttons don't submit data yet. To make it real:
- Wire the "List waste" form to a backend + database (e.g. Node/Express + PostgreSQL, or Replit's built-in DB for a fast prototype)
- Replace the mock AI estimate with a real pricing model (start with a simple lookup table by material + weight + local market price, upgrade to image-based estimation later)
- Add auth (phone number + OTP is more realistic than email for this user base)
- Integrate a real payment provider (Opay/Moniepoint/Paystack) for the wallet withdraw actions
